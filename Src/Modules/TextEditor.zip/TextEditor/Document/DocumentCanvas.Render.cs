using Avalonia;
using Avalonia.Controls;
using Avalonia.Media;
using Avalonia.Rendering.SceneGraph;
using Avalonia.Skia;
using Avalonia.Threading;
using SkiaSharp;
using System;
using System.Collections.Generic;
using Writersword.Core.Models.Rendering;
using Writersword.Modules.TextEditor.Rendering;
using Writersword.Modules.TextEditor.Models.Document;
using Writersword.Modules.TextEditor.ViewModels;

namespace Writersword.Modules.TextEditor.Document
{
    public sealed partial class DocumentCanvas
    {
        // ── Render ────────────────────────────────────────────────────────
        public override void Render(DrawingContext ctx)
        {
            ctx.Custom(new CanvasSKDrawOperation(
                this, new Rect(0, 0, Bounds.Width, Bounds.Height)));
        }

        internal void RenderWithSKCanvas(SKCanvas canvas)
        {
            if (_isTransitioning) return;

            // Дренируем очередь битмапов ожидающих удаления.
            while (_bitmapDisposeQueue.TryDequeue(out var stale))
                stale?.Dispose();

            List<ParaLayout> layouts;
            List<PageRect> pages;
            List<TableEntry> tables;
            float canvasHeightPt;
            double canvasWidth;

            lock (_renderLock)
            {
                layouts = _layouts;
                pages = _pages;
                tables = _tables;
                canvasHeightPt = _canvasHeightPt;
                canvasWidth = _canvasWidth;
            }

            double zoom = Zoom;
            float scale = (float)(PtToPx * zoom);

            int pixelW = (int)Math.Max(Bounds.Width, 1);

            // Рендерим только видимый viewport а не весь документ.
            // _viewportHeight обновляется в OnScrollViewerPropertyChanged.
            // Без ScrollViewer — fallback на Bounds.Height.
            float viewportPx = _viewportHeight > 0 ? (float)_viewportHeight : (float)Bounds.Height;

            // Overscan: рендерим ±viewport выше и ниже видимой области.
            // Когда compositor показывает стale-кадр во время скролла, старый битмап
            // уже покрывает новую позицию → нет чёрных полос.
            float scrollY = (float)_scrollOffsetY;
            float overlapPx = viewportPx;
            float docHeightPx = (float)Bounds.Height;

            // bitmapTopY — верхняя граница рендерируемой области в пикселях документа.
            float bitmapTopY = Math.Max(scrollY - overlapPx, 0f);
            // Нижняя граница не выходит за документ.
            float bitmapBotY = Math.Min(bitmapTopY + viewportPx + overlapPx * 2f, docHeightPx);
            // Если у нижней границы документа не хватает места снизу — сдвигаем верх вниз.
            bitmapTopY = Math.Max(bitmapBotY - viewportPx - overlapPx * 2f, 0f);

            int pixelH = (int)Math.Max(bitmapBotY - bitmapTopY, 1);
            float bitmapTopYInPts = scale > 0f ? bitmapTopY / scale : 0f;

            // scrollYInPts нужен только для DrawCaret (рисуется в координатах документа).
            float scrollYInPts = scale > 0f ? scrollY / scale : 0f;

            if (_caretOnlyRedraw)
            {
                SKBitmap? cached;
                int cachedW, cachedH;
                float cachedScrollY;
                lock (_bitmapLock)
                {
                    cached = _lastFullRenderBitmap;
                    cachedW = _lastFullRenderWidth;
                    cachedH = _lastFullRenderHeight;
                    cachedScrollY = _lastFullRenderScrollY;
                }

                // Кеш валиден если scroll находится внутри overscan-диапазона битмапа.
                // cachedScrollY хранит bitmapTopY — верхний край последнего рендера.
                // Если пользователь проскроллил так что viewport ещё внутри битмапа —
                // можно переиспользовать битмап без перерисовки.
                bool scrollInRange = cached is not null
                    && cachedW == pixelW
                    && scrollY >= cachedScrollY - 0.5f
                    && scrollY + viewportPx <= cachedScrollY + cachedH + 0.5f;

                if (scrollInRange)
                {
                    _caretOnlyRedraw = false;

                    // Битмап рисуем по его реальному bitmapTopY (не scrollY).
                    canvas.DrawBitmap(cached!, 0, cachedScrollY);

                    if (_caretVisible)
                    {
                        canvas.Save();
                        canvas.Scale(scale, scale);
                        DrawCaretOnCanvas(canvas, layouts, pages, canvasWidth);
                        canvas.Restore();
                    }
                    return;
                }
                _caretOnlyRedraw = false;
            }

            _caretOnlyRedraw = false;

            while (_bitmapDisposeQueue.TryDequeue(out var stale))
                stale?.Dispose();

            // Получаем или создаём render-bitmap нужного размера.
            // Если размер не изменился — переиспользуем существующий (0 аллокаций).
            // Если изменился — создаём новый и откладываем старый в очередь.
            SKBitmap? renderTarget;
            lock (_bitmapLock)
            {
                if (_renderBitmap is null || _renderBitmap.Width != pixelW || _renderBitmap.Height != pixelH)
                {
                    if (_renderBitmap is not null) _bitmapDisposeQueue.Enqueue(_renderBitmap);
                    if (_displayBitmap is not null) _bitmapDisposeQueue.Enqueue(_displayBitmap);
                    _renderBitmap = new SKBitmap(pixelW, pixelH, SKColorType.Bgra8888, SKAlphaType.Premul);
                    _displayBitmap = new SKBitmap(pixelW, pixelH, SKColorType.Bgra8888, SKAlphaType.Premul);
                    _bitmapW = pixelW;
                    _bitmapH = pixelH;
                }
                renderTarget = _renderBitmap;
            }

            if (renderTarget is not null)
            {
                // Рисуем прямо в SKBitmap — без SKSurface.Create и SKBitmap.FromImage.
                // SKCanvas(bitmap) использует уже выделенную память битмапа.
                using var offscreen = new SKCanvas(renderTarget);
                offscreen.Clear(SKColors.Transparent);
                offscreen.Save();
                offscreen.Scale(scale, scale);
                // Трансляция -bitmapTopYInPts сдвигает координаты документа
                // так что область [bitmapTopY, bitmapTopY+pixelH] ложится в битмап.
                offscreen.Translate(0f, -bitmapTopYInPts);

                var mode = DocVm?.ViewMode ?? EditorViewMode.Draft;
                if (mode == EditorViewMode.Page)
                    RenderPageMode(offscreen, layouts, pages, tables, canvasHeightPt, canvasWidth, false);
                else
                    RenderFlowMode(offscreen, mode, layouts, tables, canvasHeightPt, canvasWidth, false);

                offscreen.Restore();

                // Атомарно свапаем render и display буферы.
                SKBitmap? toDisplay;
                lock (_bitmapLock)
                {
                    (_renderBitmap, _displayBitmap) = (_displayBitmap, _renderBitmap);
                    // Сохраняем bitmapTopY — верхний край отрисованного битмапа.
                    // Используется в cache check: scroll внутри [bitmapTopY, bitmapTopY+H]?
                    _lastFullRenderScrollY = bitmapTopY;
                    toDisplay = _displayBitmap;
                }

                if (toDisplay is not null)
                    canvas.DrawBitmap(toDisplay, 0, bitmapTopY);

                if (_caretVisible)
                {
                    canvas.Save();
                    canvas.Scale(scale, scale);
                    DrawCaretOnCanvas(canvas, layouts, pages, canvasWidth);
                    canvas.Restore();
                }
            }
            else
            {
                // Fallback: рендерим напрямую в lease canvas (весь документ).
                canvas.Save();
                canvas.Scale(scale, scale);
                var mode = DocVm?.ViewMode ?? EditorViewMode.Draft;
                if (mode == EditorViewMode.Page)
                    RenderPageMode(canvas, layouts, pages, tables, canvasHeightPt, canvasWidth, _caretVisible);
                else
                    RenderFlowMode(canvas, mode, layouts, tables, canvasHeightPt, canvasWidth, _caretVisible);
                canvas.Restore();
            }
        }

        // Рисует только рамки и фон таблицы (без параграфов — они в _layouts).
        private void RenderTableStructureOnly(
            SKCanvas canvas, SKTableLayout tableLayout, float tableX, float tableY,
            int rowFrom = 0, int rowTo = -1,
            float lastRowVisibleHeightPt = -1f, float firstRowContentOffsetPt = 0f,
            bool isContinuation = false)
        {
            var m = canvas.TotalMatrix;
            float canvasScale = MathF.Sqrt(m.ScaleX * m.ScaleX + m.SkewY * m.SkewY);
            if (canvasScale < 0.01f) canvasScale = 1f;

            int effectiveRowTo = rowTo < 0 ? tableLayout.Rows.Count : rowTo;
            float rowOffsetY = rowFrom > 0 && rowFrom < tableLayout.Rows.Count
                ? tableLayout.Rows[rowFrom].Ypt : 0f;

            // maxPadTop — верхний паддинг первой строки продолжения.
            // Используется сразу в двух местах: увеличивает effectiveRowH строки rowFrom
            // (чтобы нижний паддинг был виден) и уменьшает extraShift последующих строк
            // (чтобы они не отрывались от первой строки). Оба изменения должны быть одинаковыми.
            float maxPadTop = 0f;
            if (isContinuation && firstRowContentOffsetPt > 0f && rowFrom < tableLayout.Rows.Count)
            {
                foreach (var cell in tableLayout.Rows[rowFrom].Cells)
                    maxPadTop = Math.Max(maxPadTop, cell.PadTopPt + cell.Borders.Top.WidthPt);
            }

            foreach (var row in tableLayout.Rows)
            {
                if (row.Row < rowFrom || row.Row >= effectiveRowTo) continue;

                bool isFirstRow = row.Row == rowFrom;
                bool isLastRow = row.Row == effectiveRowTo - 1;
                float rowShift = isFirstRow ? firstRowContentOffsetPt : 0f;
                float effectiveRowH = isFirstRow
                    ? row.HeightPt - rowShift + maxPadTop
                    : row.HeightPt;

                float visibleH = (isLastRow && lastRowVisibleHeightPt >= 0f)
                    ? lastRowVisibleHeightPt
                    : effectiveRowH;

                // Для строк после rowFrom сдвигаем вверх на (firstRowContentOffsetPt - maxPadTop),
                // чтобы верхняя граница строки N совпадала с нижней границей строки rowFrom.
                float extraShift = isFirstRow ? 0f : (firstRowContentOffsetPt - maxPadTop);

                foreach (var cell in row.Cells)
                {
                    float cellX = tableX + cell.Xpt;
                    float cellY = tableY + cell.Ypt - rowOffsetY - rowShift - extraShift;

                    if (!string.IsNullOrEmpty(cell.BackgroundColor)
                        && SKColor.TryParse(cell.BackgroundColor, out var bgColor))
                    {
                        // Мутируем Color кешированного паинта — безопасно на compositor-треде.
                        _paintCellBg.Color = bgColor;
                        canvas.DrawRect(cellX, cellY + rowShift, cell.WidthPt, visibleH, _paintCellBg);
                    }

                    float visibleCellY = cellY + rowShift;

                    SKTextRenderer.RenderCellBordersPublic(canvas, cell, cellX, visibleCellY,
                        visibleH, canvasScale, false, false);
                }
            }
        }

        private void RenderTableSelection(SKCanvas canvas, List<TableEntry> tables,
            TableBlock table, int startRow, int startCol, int endRow, int endCol)
        {
            int minRow = Math.Min(startRow, endRow);
            int maxRow = Math.Max(startRow, endRow);
            int minCol = Math.Min(startCol, endCol);
            int maxCol = Math.Max(startCol, endCol);

            foreach (var te in tables)
            {
                if (te.Table != table) continue;

                int effectiveRowTo = te.RowTo < 0 ? te.Layout.Rows.Count : te.RowTo;
                float rowOffsetY = te.RowFrom > 0 && te.RowFrom < te.Layout.Rows.Count
                    ? te.Layout.Rows[te.RowFrom].Ypt : 0f;

                float maxPadTop = 0f;
                if (te.IsContinuation && te.FirstRowContentOffsetPt > 0f
                    && te.RowFrom < te.Layout.Rows.Count)
                {
                    foreach (var cell in te.Layout.Rows[te.RowFrom].Cells)
                        maxPadTop = Math.Max(maxPadTop, cell.PadTopPt + cell.Borders.Top.WidthPt);
                }

                foreach (var row in te.Layout.Rows)
                {
                    if (row.Row < te.RowFrom || row.Row >= effectiveRowTo) continue;
                    if (row.Row < minRow || row.Row > maxRow) continue;

                    bool isFirstRow = row.Row == te.RowFrom;
                    float rowShift = isFirstRow ? te.FirstRowContentOffsetPt : 0f;
                    float extraShift = isFirstRow ? 0f : (te.FirstRowContentOffsetPt - maxPadTop);
                    float effectiveRowH = isFirstRow
                        ? row.HeightPt - rowShift + maxPadTop
                        : row.HeightPt;

                    float visibleH = (row.Row == effectiveRowTo - 1 && te.LastRowVisibleHeightPt >= 0f)
                        ? te.LastRowVisibleHeightPt
                        : effectiveRowH;

                    foreach (var cell in row.Cells)
                    {
                        if (cell.Column < minCol || cell.Column > maxCol) continue;
                        float cellX = te.XPt + cell.Xpt;
                        float cellY = te.Ypt + cell.Ypt - rowOffsetY - rowShift - extraShift;
                        canvas.DrawRect(cellX, cellY + rowShift, cell.WidthPt, visibleH, _paintSelection);
                    }
                }
            }
        }

        private void RenderFrozenTableSelection(SKCanvas canvas, List<TableEntry> tables, FrozenTableSelection frozen)
            => RenderTableSelection(canvas, tables, frozen.Table, frozen.StartRow, frozen.StartCol, frozen.EndRow, frozen.EndCol);

        // Цвета ручек
        private static readonly SKColor HandleFill = new(0x22, 0x99, 0xFF, 0xCC);
        private static readonly SKColor HandleStroke = new(0xFF, 0xFF, 0xFF, 0xCC);

        /// <summary>
        /// Рисует ↔-ручки на внутренних границах колонок и правом крае таблицы (по центру высоты),
        /// и ↕-ручку на нижнем крае таблицы (по центру ширины).
        /// Ручки рисуются только для активной таблицы (где стоит каретка).
        /// </summary>
        private void RenderTableHandles(SKCanvas canvas, TableEntry te)
        {
            if (!ReferenceEquals(te.Table, _activeTableBlock)) return;

            var layout = te.Layout;
            float tableX = te.XPt;
            float tableY = te.Ypt;
            float tableW = layout.TotalWidthPt;

            // Высота видимого слайса — от tableY до конца последней видимой строки.
            // Используем реальную высоту слайса, а не полную высоту таблицы,
            // чтобы ручки не выходили за пределы видимой области.
            float sliceH = 0f;
            int effectiveRowTo = te.RowTo < 0 ? layout.Rows.Count : te.RowTo;
            for (int ri = te.RowFrom; ri < effectiveRowTo && ri < layout.Rows.Count; ri++)
            {
                float rowH = layout.Rows[ri].HeightPt;
                if (ri == te.RowFrom) rowH -= te.FirstRowContentOffsetPt;
                if (ri == effectiveRowTo - 1 && te.LastRowVisibleHeightPt >= 0f)
                    rowH = te.LastRowVisibleHeightPt;
                sliceH += rowH;
            }
            if (sliceH <= 0f) return;

            const float HW = 6f;
            const float HH = 4f;


            // ↔ на каждой внутренней и внешней правой границе колонки (по центру Y слайса)
            float midY = tableY + sliceH / 2f;
            float accX = tableX;
            for (int i = 0; i < layout.ColumnWidthsPt.Count; i++)
            {
                accX += layout.ColumnWidthsPt[i];
                DrawHandle(canvas, accX, midY, HW, HH, _paintHandleFill, _paintHandleStroke, horizontal: true);
            }

            // ↕ на нижнем краю слайса по центру ширины
            float midX = tableX + tableW / 2f;
            DrawHandle(canvas, midX, tableY + sliceH, HH, HW, _paintHandleFill, _paintHandleStroke, horizontal: false);

            // ↔ на левом крае (для сдвига всей таблицы)
            DrawHandle(canvas, tableX, midY, HW, HH, _paintHandleFill, _paintHandleStroke, horizontal: true);
        }

        private void DrawHandle(SKCanvas canvas,
            float cx, float cy, float hw, float hh,
            SKPaint fill, SKPaint stroke, bool horizontal)
        {
            var rect = new SKRect(cx - hw, cy - hh, cx + hw, cy + hh);
            canvas.DrawRoundRect(rect, 2f, 2f, fill);
            canvas.DrawRoundRect(rect, 2f, 2f, stroke);

            // Стрелочки внутри
            if (horizontal)
            {
                // ←
                canvas.DrawLine(cx - hw + 1.5f, cy, cx - 1f, cy, _paintHandleArrow);
                canvas.DrawLine(cx - hw + 1.5f, cy, cx - hw + 3.5f, cy - 2f, _paintHandleArrow);
                canvas.DrawLine(cx - hw + 1.5f, cy, cx - hw + 3.5f, cy + 2f, _paintHandleArrow);
                // →
                canvas.DrawLine(cx + hw - 1.5f, cy, cx + 1f, cy, _paintHandleArrow);
                canvas.DrawLine(cx + hw - 1.5f, cy, cx + hw - 3.5f, cy - 2f, _paintHandleArrow);
                canvas.DrawLine(cx + hw - 1.5f, cy, cx + hw - 3.5f, cy + 2f, _paintHandleArrow);
            }
            else
            {
                // ↑
                canvas.DrawLine(cx, cy - hh + 1.5f, cx, cy - 1f, _paintHandleArrow);
                canvas.DrawLine(cx, cy - hh + 1.5f, cx - 2f, cy - hh + 3.5f, _paintHandleArrow);
                canvas.DrawLine(cx, cy - hh + 1.5f, cx + 2f, cy - hh + 3.5f, _paintHandleArrow);
                // ↓
                canvas.DrawLine(cx, cy + hh - 1.5f, cx, cy + 1f, _paintHandleArrow);
                canvas.DrawLine(cx, cy + hh - 1.5f, cx - 2f, cy + hh - 3.5f, _paintHandleArrow);
                canvas.DrawLine(cx, cy + hh - 1.5f, cx + 2f, cy + hh - 3.5f, _paintHandleArrow);
            }
        }

        private void RenderPageMode(
            SKCanvas canvas,
            List<ParaLayout> layouts,
            List<PageRect> pages,
            List<TableEntry> tables,
            float canvasHeightPt,
            double canvasWidth,
            bool drawCaret)
        {
            float canvasWPt = (float)(canvasWidth * PxToPt);

            canvas.DrawRect(0, 0, canvasWPt, canvasHeightPt, _paintCanvasBg);

            var (firstPage, lastPage) = GetVisiblePageRange(pages);

            for (int pi = firstPage; pi <= lastPage && pi < pages.Count; pi++)
            {
                var page = pages[pi];
                canvas.DrawRect(page.PadLeftPt + 3, page.Ypt + 3, page.WidthPt, page.HeightPt, _paintPageShadow);
                canvas.DrawRect(page.PadLeftPt, page.Ypt, page.WidthPt, page.HeightPt, _paintPageWhite);
            }

            // Рисуем рамки таблиц (без содержимого) — клипуем по правому краю страницы
            foreach (var te in tables)
            {
                if (te.PageIndex < firstPage || te.PageIndex > lastPage) continue;
                // Клип по правому краю страницы: таблица может выходить за край,
                // но видна только в пределах страницы.
                // По вертикали клипуем по полной высоте страницы (включая поля),
                // а не по текстовой зоне — иначе нижняя граница последней ByRow-строки
                // (расположенная точно на textBottom) обрезается исключающим клипом.
                // Корректное отсечение лишних линий обеспечивают suppressBottom/visibleH.
                if (te.PageIndex < pages.Count)
                {
                    var pg = pages[te.PageIndex];
                    float pageRight = pg.PadLeftPt + pg.WidthPt;
                    float pageTop = pg.Ypt;
                    float pageBottom = pg.Ypt + pg.HeightPt;
                    canvas.Save();
                    canvas.ClipRect(new SKRect(0, pageTop, pageRight, pageBottom));
                    RenderTableStructureOnly(canvas, te.Layout, te.XPt, te.Ypt,
                        te.RowFrom, te.RowTo,
                        te.LastRowVisibleHeightPt, te.FirstRowContentOffsetPt,
                        te.IsContinuation);
                    canvas.Restore();
                }
                else
                {
                    RenderTableStructureOnly(canvas, te.Layout, te.XPt, te.Ypt,
                        te.RowFrom, te.RowTo,
                        te.LastRowVisibleHeightPt, te.FirstRowContentOffsetPt,
                        te.IsContinuation);
                }
            }

            for (int i = 0; i < layouts.Count; i++)
            {
                var pl = layouts[i];
                if (pl.PageIndex < firstPage || pl.PageIndex > lastPage) continue;

                // Для ячеек таблицы дополнительно клипуем по правому краю страницы
                // (ячейка может выходить за край, текст должен быть обрезан).
                if (pl.Cell != null && pl.PageIndex < pages.Count)
                {
                    var pg = pages[pl.PageIndex];
                    float pageRight = pg.PadLeftPt + pg.WidthPt;
                    float textTop = pg.Ypt + pg.PadTopPt;
                    float textBottom = pg.Ypt + pg.HeightPt - pg.PadBottomPt;
                    canvas.Save();
                    canvas.ClipRect(new SKRect(0, textTop, pageRight, textBottom));
                    RenderParaLayout(canvas, i, pl, layouts, drawCaret);
                    canvas.Restore();
                }
                else
                {
                    RenderParaLayout(canvas, i, pl, layouts, drawCaret);
                }
            }

            // Рисуем выделения всех таблиц из единого словаря.
            foreach (var kv in _tableSelections)
                RenderTableSelection(canvas, tables, kv.Key, kv.Value.sr, kv.Value.sc, kv.Value.er, kv.Value.ec);
        }

        private void RenderFlowMode(
            SKCanvas canvas,
            EditorViewMode mode,
            List<ParaLayout> layouts,
            List<TableEntry> tables,
            float canvasHeightPt,
            double canvasWidth,
            bool drawCaret)
        {
            float canvasWPt = (float)(canvasWidth * PxToPt);

            canvas.DrawRect(0, 0, canvasWPt, canvasHeightPt, _paintTransparent);

            float zoom2 = (float)Zoom;
            float viewTopPt = (float)(_scrollOffsetY / zoom2 * PxToPt) - FallbackLinePt * 5f;
            float viewBotPt = (float)((_scrollOffsetY + Math.Max(_viewportHeight, 100))
                / zoom2 * PxToPt) + FallbackLinePt * 5f;

            foreach (var te in tables)
            {
                if (te.Ypt + te.Layout.TotalHeightPt < viewTopPt) continue;
                if (te.Ypt > viewBotPt) break;
                RenderTableStructureOnly(canvas, te.Layout, te.XPt, te.Ypt);
            }

            for (int i = 0; i < layouts.Count; i++)
            {
                var pl = layouts[i];
                if (pl.Ypt + pl.HeightPt < viewTopPt) continue;
                if (pl.Ypt > viewBotPt) break;

                RenderParaLayout(canvas, i, pl, layouts, drawCaret);
            }
        }

        /// <summary>
        /// Рисует один параграф (обычный или в ячейке таблицы).
        /// Для ячейки применяет clip-rect.
        /// </summary>
        private void RenderParaLayout(
            SKCanvas canvas, int idx, ParaLayout pl,
            List<ParaLayout> layouts, bool drawCaret)
        {
            float absX = pl.AbsXPt;
            float absY = pl.Ypt;

            bool isCell = pl.Cell != null;

            if (isCell)
            {
                canvas.Save();
                var clip = pl.Cell!;
                canvas.ClipRect(new SKRect(clip.ClipX, clip.ClipY,
                    clip.ClipX + clip.ClipW, clip.ClipY + clip.ClipH));
            }

            var renderLayout = GetRenderLayout(pl, (float)(_canvasWidth * PxToPt));

            DrawSelectionForSlice(canvas, idx, pl, absX, absY, layouts, renderLayout);

            SKTextRenderer.RenderParagraphLines(
                canvas, renderLayout,
                absX + renderLayout.LeftIndentPt,
                absY,
                pl.LineFrom, pl.LineTo);

            if (drawCaret && _caretPara == idx)
                DrawCaret(canvas, pl, absX, absY, renderLayout);

            if (isCell)
                canvas.Restore();
        }

        private void DrawCaretOnCanvas(
            SKCanvas canvas,
            List<ParaLayout> layouts,
            List<PageRect> pages,
            double canvasWidth)
        {
            if (!_caretVisible) return;
            if (_caretPara < 0 || _caretPara >= layouts.Count) return;

            var pl = layouts[_caretPara];
            var caretLayout = GetRenderLayout(pl, (float)(_canvasWidth * PxToPt));
            float xPt = pl.AbsXPt;

            // В page-режиме применяем page-level клип (как RenderPageMode делает для параграфов),
            // иначе каретка на последней строке может выходить за нижнюю рамку таблицы/страницы.
            bool hasPageClip = pages.Count > 0 && pl.PageIndex < pages.Count;
            if (hasPageClip)
            {
                var pg = pages[pl.PageIndex];
                canvas.Save();
                canvas.ClipRect(new SKRect(0, pg.Ypt, pg.PadLeftPt + pg.WidthPt, pg.Ypt + pg.HeightPt));
            }

            bool isCell = pl.Cell != null;
            if (isCell)
            {
                if (!hasPageClip) canvas.Save();
                var c = pl.Cell!;
                canvas.ClipRect(new SKRect(c.ClipX, c.ClipY, c.ClipX + c.ClipW, c.ClipY + c.ClipH));
            }

            DrawCaret(canvas, pl, xPt, pl.Ypt);

            if (isCell || hasPageClip) canvas.Restore();
        }

        private (int first, int last) GetVisiblePageRange(List<PageRect> pages)
        {
            if (pages.Count == 0) return (0, 0);
            double zoom2 = Zoom;
            float viewTopPt = (float)(_scrollOffsetY / zoom2 * PxToPt);
            float viewBotPt = (float)((_scrollOffsetY + Math.Max(_viewportHeight, 100)) / zoom2 * PxToPt);
            float bufferPt = (pages.Count > 0 ? pages[0].HeightPt : 842f) + PageGapPt;
            viewTopPt -= bufferPt;
            viewBotPt += bufferPt;

            int first = 0, last = pages.Count - 1;
            for (int i = 0; i < pages.Count; i++)
                if (pages[i].Ypt + pages[i].HeightPt >= viewTopPt) { first = i; break; }
            for (int i = first; i < pages.Count; i++)
            {
                last = i;
                if (pages[i].Ypt > viewBotPt) break;
            }
            return (first, last);
        }

        private void DrawSelectionForSlice(
            SKCanvas canvas, int sliceIdx, ParaLayout pl,
            float xPt, float yPt, List<ParaLayout> layouts,
            SKTextLayout? resolvedLayout = null)
        {
            // Ячейки при активном cell-range или табличном выделении: рисуется через RenderTableSelection.
            if (pl.Cell != null && (_isCellRangeSelecting || _tableSelections.ContainsKey(pl.Cell.Table))) return;

            if (!HasSel()) return;

            var (sp, sc, ep, ec) = NormalizeSelection();
            if (sliceIdx < sp || sliceIdx > ep) return;

            int len = pl.Vm.PlainText?.Length ?? 0;

            // Пустые параграфы-якоря вокруг таблиц при активном табличном выделении
            // пропускаем — они дают тонкую полосу выделения вплотную к рамке таблицы.
            if (len == 0 && _tableSelections.Count > 0
                && (IsBlockBeforeTable(pl.Vm.Model) || IsBlockAfterTable(pl.Vm.Model)))
                return;

            int from = sliceIdx == sp ? sc : 0;
            int to = sliceIdx == ep ? ec : len;

            from = Clamp(from, 0, len);
            to = Clamp(to, 0, len);
            if (from >= to && !(from == 0 && len == 0)) return;

            var sl = resolvedLayout ?? pl.Layout;
            if (sl is null) return;

            if (from == to && len == 0)
            {
                float lineH = sl.Lines.Count > 0 ? sl.Lines[0].Height : FallbackLinePt;
                canvas.DrawRect(xPt, yPt, 5f, lineH, _paintSelection);
                return;
            }

            var rects = sl.HitTestRange(from, to);
            if (rects.Count == 0) return;

            foreach (var r in rects)
            {
                if (r.LineIndex < pl.LineFrom || r.LineIndex >= pl.LineTo) continue;
                canvas.DrawRect(
                    xPt + r.Rect.Left,
                    yPt + r.Rect.Top,
                    r.Rect.Width, r.Rect.Height, _paintSelection);
            }
        }

        private void DrawCaret(SKCanvas canvas, ParaLayout pl, float xPt, float yPt, SKTextLayout? resolvedLayout = null)
        {
            var layout = resolvedLayout ?? pl.Layout;
            if (layout is null) return;
            // Якорный параграф (пустой текст) — рисуем каретку напрямую в его позиции.
            if (string.IsNullOrEmpty(pl.Vm.PlainText))
            {
                canvas.DrawLine(xPt, yPt, xPt, yPt + FallbackLinePt, _paintCaret);
                return;
            }

            int pos = Clamp(_caretChar, 0, pl.Vm.PlainText?.Length ?? 0);

            int drawLineIdx;
            SKCaretRect caret;

            if (_caretLineHint >= 0
                && _caretLineHint >= pl.LineFrom
                && _caretLineHint < Math.Min(pl.LineTo, layout.Lines.Count))
            {
                var hintLine = layout.Lines[_caretLineHint];
                if (pos > hintLine.LastCharIndex && !hintLine.IsLastLine)
                {
                    var lastSeg = hintLine.Segments.Count > 0 ? hintLine.Segments[^1] : null;
                    float hintLineExtra = (_caretLineHint == 0) ? layout.FirstLineIndentPt : 0f;
                    caret = new SKCaretRect
                    {
                        X = lastSeg != null
                            ? layout.LeftIndentPt + hintLineExtra + lastSeg.X + lastSeg.Width
                            : layout.LeftIndentPt + hintLineExtra,
                        Y = hintLine.Y,
                        Height = hintLine.Height,
                        Baseline = hintLine.Baseline
                    };
                    drawLineIdx = _caretLineHint;
                }
                else
                {
                    caret = layout.HitTestPosition(pos);
                    drawLineIdx = _caretLineHint;
                }
            }
            else
            {
                caret = layout.HitTestPosition(pos);
                drawLineIdx = layout.GetLineIndexForChar(pos);
            }

            // RenderParagraphLines рендерит строки со смещением: line.Y - lines[lineFrom].Y.
            // DrawCaret должен использовать тот же yBase, иначе каретка окажется ниже текста
            // на величину lines[lineFrom].Y — что особенно заметно на страницах продолжения.
            float yBase = pl.LineFrom < layout.Lines.Count
                ? layout.Lines[pl.LineFrom].Y : 0f;

            float cx = xPt + caret.X;
            float cy = yPt + (caret.Y - yBase);
            canvas.DrawLine(cx, cy, cx, cy + caret.Height, _paintCaret);
        }

    }
}