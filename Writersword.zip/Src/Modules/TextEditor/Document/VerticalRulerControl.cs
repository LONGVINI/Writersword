﻿using Avalonia;
using Avalonia.Controls;
using Avalonia.Media;
using Avalonia.Rendering.SceneGraph;
using Avalonia.Skia;
using SkiaSharp;
using System;
using Writersword.Modules.TextEditor.ViewModels.Components;

namespace Writersword.Modules.TextEditor.Document
{
    /// <summary>
    /// Вертикальная линейка редактора.
    /// Skia-контрол — рисует шкалу высоты страницы с учётом скролла.
    /// Показывает верхнее и нижнее поле страницы серым фоном.
    /// Не поддерживает drag — только отображение.
    /// </summary>
    public sealed class VerticalRulerControl : Control
    {
        // ── Константы геометрии ───────────────────────────────────────────

        // Ширина контрола в пикселях.
        private const double RulerWidthPx = 24.0;

        // Высота основного деления шкалы в пикселях.
        private const double MajorTickWidthPx = 10.0;

        // Высота среднего деления шкалы в пикселях.
        private const double MinorTickWidthPx = 6.0;

        // Высота малого деления шкалы в пикселях.
        private const double TinyTickWidthPx = 3.0;

        // ── Цвета ─────────────────────────────────────────────────────────

        private static readonly SKColor ColorBackground = new(0xF0, 0xF0, 0xF0);
        private static readonly SKColor ColorMarginZone = new(0xD8, 0xD8, 0xD8);
        private static readonly SKColor ColorTickMajor = new(0x60, 0x60, 0x60);
        private static readonly SKColor ColorTickMinor = new(0x99, 0x99, 0x99);
        private static readonly SKColor ColorTickTiny = new(0xBB, 0xBB, 0xBB);
        private static readonly SKColor ColorLabel = new(0x44, 0x44, 0x44);
        private static readonly SKColor ColorBorder = new(0xCC, 0xCC, 0xCC);

        // ── Состояние ─────────────────────────────────────────────────────

        private RulerViewModel? _vm;

        // ── Конструктор ───────────────────────────────────────────────────

        public VerticalRulerControl()
        {
            Width = RulerWidthPx;
        }

        // ── Привязка к ViewModel ──────────────────────────────────────────

        protected override void OnDataContextChanged(EventArgs e)
        {
            base.OnDataContextChanged(e);

            if (_vm is not null)
                _vm.PropertyChanged -= OnVmPropertyChanged;

            _vm = DataContext as RulerViewModel;

            if (_vm is not null)
                _vm.PropertyChanged += OnVmPropertyChanged;

            InvalidateVisual();
        }

        private void OnVmPropertyChanged(object? sender,
            System.ComponentModel.PropertyChangedEventArgs e)
        {
            InvalidateVisual();
        }

        // ── Render ────────────────────────────────────────────────────────

        public override void Render(DrawingContext ctx)
        {
            ctx.Custom(new RulerSKDrawOperation(
                this, new Rect(0, 0, Bounds.Width, Bounds.Height)));
        }

        internal void RenderWithSKCanvas(SKCanvas canvas)
        {
            if (_vm is null) return;

            float w = (float)RulerWidthPx;
            float h = (float)Bounds.Height;

            // Фон.
            using var bgPaint = new SKPaint { Color = ColorBackground };
            canvas.DrawRect(0, 0, w, h, bgPaint);

            double zoom = _vm.Zoom;
            double scrollY = _vm.ScrollOffsetY;

            const double PageGapPt = 15.0;
            const double PtToPx = 96.0 / 72.0;

            double pageGapPx = PageGapPt * PtToPx * zoom;
            double pageHeightPx = MmToPx(_vm.PageHeightMm, zoom);
            double marginTopPx = MmToPx(_vm.MarginTopMm, zoom);
            double marginBotPx = MmToPx(_vm.MarginBottomMm, zoom);

            double pageWithGapPx = pageHeightPx + pageGapPx;

            // Определяем какая страница сейчас первая видимая.
            // Первая страница начинается с pageGapPx от верха канваса.
            double scrollFromFirstPage = Math.Max(0, scrollY - pageGapPx);
            int currentPage = (int)(scrollFromFirstPage / pageWithGapPx);
            double pageTopY = pageGapPx
                                         + currentPage * pageWithGapPx
                                         - scrollY;

            // Рисуем несколько страниц — столько сколько видно в viewport.
            int pagesToDraw = (int)Math.Ceiling(h / pageWithGapPx) + 2;

            for (int pi = 0; pi < pagesToDraw; pi++)
            {
                double pTopY = pageTopY + pi * pageWithGapPx;
                double pBotY = pTopY + pageHeightPx;
                double tTopY = pTopY + marginTopPx;
                double tBotY = pBotY - marginBotPx;

                // Зона верхнего поля — серый.
                using var marginPaint = new SKPaint { Color = ColorMarginZone };

                if (pTopY > 0 && pTopY < h)
                    canvas.DrawRect(0, (float)pTopY,
                        w, (float)Math.Min(marginTopPx, h - pTopY), marginPaint);
                else if (pTopY <= 0 && tTopY > 0)
                    canvas.DrawRect(0, 0,
                        w, (float)Math.Min(tTopY, h), marginPaint);

                // Зона нижнего поля — серый.
                if (tBotY < h && pBotY > tBotY)
                    canvas.DrawRect(0, (float)Math.Max(0, tBotY),
                        w, (float)(Math.Min(h, pBotY) - Math.Max(0, tBotY)), marginPaint);

                // Зазор между страницами — серый.
                if (pBotY > 0 && pBotY < h)
                {
                    float gapH = (float)Math.Min(pageGapPx, h - pBotY);
                    if (gapH > 0)
                        canvas.DrawRect(0, (float)pBotY, w, gapH, marginPaint);
                }

                // Шкала делений для этой страницы.
                DrawScale(canvas, tTopY, tBotY, w, h, zoom);
            }

            // Правая граница.
            using var borderPaint = new SKPaint
            {
                Color = ColorBorder,
                StrokeWidth = 1f,
                IsStroke = true
            };
            canvas.DrawLine(w - 0.5f, 0, w - 0.5f, h, borderPaint);
        }

        /// <summary>
        /// Рисует шкалу делений с подписями.
        /// Ноль шкалы — верхний край текстовой области страницы.
        /// </summary>
        private void DrawScale(
            SKCanvas canvas,
            double textTopY,
            double textBottomY,
            float w,
            float h,
            double zoom)
        {
            if (_vm is null) return;

            double unitSizePx = UnitSizePx(zoom);
            double majorInterval = _vm.MajorTickInterval;
            double minorInterval = _vm.MinorTickInterval;
            double tinyInterval = _vm.TinyTickInterval;

            double textHeightUnits = _vm.MmToUnits(
                _vm.PageHeightMm - _vm.MarginTopMm - _vm.MarginBottomMm);

            using var majorPaint = new SKPaint
            {
                Color = ColorTickMajor,
                StrokeWidth = 1f,
                IsStroke = true,
                IsAntialias = false
            };
            using var minorPaint = new SKPaint
            {
                Color = ColorTickMinor,
                StrokeWidth = 1f,
                IsStroke = true,
                IsAntialias = false
            };
            using var tinyPaint = new SKPaint
            {
                Color = ColorTickTiny,
                StrokeWidth = 1f,
                IsStroke = true,
                IsAntialias = false
            };
            using var labelPaint = new SKPaint
            {
                Color = ColorLabel,
                IsAntialias = true
            };

            using var typeface = SKTypeface.FromFamilyName("Arial", SKFontStyle.Normal)
                ?? SKTypeface.Default;
            using var font = new SKFont(typeface, 8f);

            double maxUnits = textHeightUnits + majorInterval;
            double step = tinyInterval;
            int stepCount = (int)Math.Ceiling(maxUnits / step) + 1;

            for (int i = 0; i <= stepCount; i++)
            {
                double unitValue = i * step;
                double yPx = textTopY + unitValue * unitSizePx;

                if (yPx < 0 || yPx > h) continue;

                float y = (float)yPx;

                bool isMajor = IsMultiple(unitValue, majorInterval);
                bool isMinor = !isMajor && IsMultiple(unitValue, minorInterval);

                float tickW = isMajor
                    ? (float)MajorTickWidthPx
                    : isMinor
                        ? (float)MinorTickWidthPx
                        : (float)TinyTickWidthPx;

                var paint = isMajor ? majorPaint : isMinor ? minorPaint : tinyPaint;

                // Деления рисуем справа (у правого края контрола).
                canvas.DrawLine(w - tickW, y, w, y, paint);

                // Подпись только на основных делениях кроме нуля.
                if (isMajor && unitValue > 0.001)
                {
                    string label = _vm.Units == Models.Settings.RulerUnits.Inches
                        ? unitValue.ToString("0.##")
                        : ((int)Math.Round(unitValue * 10)).ToString();

                    using var saveState = new SKAutoCanvasRestore(canvas, true);

                    // Поворачиваем текст на 90 градусов для вертикальной подписи.
                    canvas.Translate(w - tickW - 2f, y);
                    canvas.RotateDegrees(-90);

                    float textW = font.MeasureText(label);
                    canvas.DrawText(label, -textW / 2f, 0, font, labelPaint);
                }
            }
        }

        // ── Вспомогательные методы ────────────────────────────────────────

        /// <summary>
        /// Размер одной единицы линейки в пикселях с учётом зума.
        /// </summary>
        private double UnitSizePx(double zoom)
        {
            if (_vm is null) return 96.0 * zoom;
            double unitMm = _vm.Units == Models.Settings.RulerUnits.Inches ? 25.4 : 10.0;
            return unitMm * (96.0 / 25.4) * zoom;
        }

        /// <summary>
        /// Конвертирует миллиметры в пиксели с учётом зума.
        /// </summary>
        private static double MmToPx(double mm, double zoom)
            => mm * (96.0 / 25.4) * zoom;

        /// <summary>
        /// Проверяет кратность значения шагу с допуском на погрешность float.
        /// </summary>
        private static bool IsMultiple(double value, double step)
        {
            if (step <= 0) return false;
            double remainder = Math.Abs(value % step);
            return remainder < step * 0.01 || remainder > step * 0.99;
        }

        // ── ICustomDrawOperation ──────────────────────────────────────────

        private sealed class RulerSKDrawOperation : ICustomDrawOperation
        {
            private readonly VerticalRulerControl _ruler;
            public Rect Bounds { get; }

            public RulerSKDrawOperation(VerticalRulerControl ruler, Rect bounds)
            {
                _ruler = ruler;
                Bounds = bounds;
            }

            public void Dispose() { }
            public bool Equals(ICustomDrawOperation? other) => false;
            public bool HitTest(Point p) => true;

            public void Render(ImmediateDrawingContext context)
            {
                var feature = context.TryGetFeature(typeof(ISkiaSharpApiLeaseFeature))
                    as ISkiaSharpApiLeaseFeature;
                if (feature is null) return;
                using var lease = feature.Lease();
                _ruler.RenderWithSKCanvas(lease.SkCanvas);
            }
        }
    }
}