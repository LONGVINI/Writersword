using System;
using System.Globalization;
using Writersword.Resources.Localization;
using Writersword.Core.Interfaces.Services.UI;

namespace Writersword.Infrastructure.Services.UI
{
    /// <summary>
    /// ������ �����������
    /// </summary>
    public class LocalizationService : ILocalizationService
    {
        private string _currentLanguage = "en";

        public string CurrentLanguage => _currentLanguage;

        public event Action? LanguageChanged;

        /// <summary>�������� ������ �� ��������</summary>
        public string GetString(string key)
        {
            try
            {
                // ������ ������ Strings (�� Resources.Localization.Strings)
                var value = Strings.ResourceManager.GetString(key, Strings.Culture);
                return value ?? $"[{key}]";
            }
            catch
            {
                return $"[{key}]";
            }
        }

        /// <summary>������� ����</summary>
        public void SetLanguage(string languageCode)
        {
            _currentLanguage = languageCode;

            var culture = new CultureInfo(languageCode);
            CultureInfo.CurrentUICulture = culture;
            CultureInfo.CurrentCulture = culture;

            Strings.Culture = culture;

            LanguageChanged?.Invoke();
        }
    }
}